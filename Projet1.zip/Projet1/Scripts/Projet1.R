                                                   #TP 1 - Logiciel statistique R
#néttoyons d'abord l'environnement de Travail.
rm(list = ls())
               
                                                   #1.2	Importation et mise en forme

#Importons la base de données
# Charger la bibliothèque
library(dplyr)
library(readxl)
getwd()
setwd("C:/Users/user/Desktop/ISEP 3/S2/COURS DE R/Projet1/Input_data")
chemin_principal <- getwd()

# Chemin relatif vers le fichier
chemin_relatif <- file.path(chemin_principal, "Base_Projet.xlsx")

# Importation de la base de données
projet <- read_excel(chemin_relatif)
View(projet)

#•	Donner le nombre de lignes et colonnes de la base projet	
dimension_data <- dim(projet)
cat("Nombre de lignes (observations) :", dimension_data[1], "\n")
cat("Nombre de colonnes (variables) :", dimension_data[2], "\n")

# Vérifier les valeurs manquantes pour la variable "key"
valeurs_manquantes <- sum(is.na(projet$key))

# Afficher le nombre de valeurs manquantes
cat("Nombre de valeurs manquantes pour la variable 'key' :", valeurs_manquantes, "\n")


                                                    #1.3	Création de variables"
#Rénommons la variable q1 en region
projet<-rename(projet,"region" = "q1")

#Rénommer la variable q2 en departement
projet<-rename (projet,"departement" = "q2")

#Rénommer la variable q23 en sexe
projet<-rename(projet,"sexe" = "q23")

View(projet)

#Créer la variable sexe_2 qui vaut 1 si sexe égale à Femme et 0 sinon.
unique(projet$sexe)
projet <- projet %>%
  mutate(sexe_2 = ifelse(sexe == "Femme", 1, 0))


# Sélectionner les colonnes qui commencent par "q24a_" et la colonne "key"
colonne_names_q24a_ <- grep("^q24a_", colnames(projet), value = TRUE)
colonnes_langues <- c(colonne_names_q24a_, "key")

# Créons le data.frame langues avec les colonnes sélectionnées
langues <- projet[, colonnes_langues]

View(langues)

#Créer une variable parle qui est égale au nombre de langue parlée par le dirigeant de la PME.
projet$parle <- rowSums(projet[, grep("^q24a_", names(projet))])
View(projet)

#Sélectionnez uniquement les variables key et parle, l’objet de retour sera langues.
langues <- select(projet, key, parle)
View(langues)

# Fusionner les data.frames projet et langues par la variable "key"
fusion <- merge(projet, langues, by = "key")
View(fusion)

                                                   #2	Analyses descriptives

#Création de fonction pour les Statistiques descriptives.

univarie <- function(projet, column) {
  # Calculer la distribution des fréquences pour la colonne
  distribution <- prop.table(table(projet[[column]])) * 100
  statistiques_descriptives <- summary(projet[[column]])
  # Exemple : Créer un graphique à barres pour la colonne "sexe"
  barplot(distribution, main = paste("Répartition des PME selon", column),
          xlab = column, ylab = "Proportion", col = c("blue", "pink"))
  return(list(distribution = distribution, statistiques_descriptives = statistiques_descriptives))
}
univarie(projet,"sexe")
univarie(projet,"q25")
univarie(projet,"q12")
univarie(projet,"q81")

bivarie <- function(projet, column1, column2) {
  # Calculer la table de contingence croisée entre les deux colonnes
  cross_tab <- table(projet[[column1]], projet[[column2]]) / nrow(projet) * 100
  barplot(cross_tab, main = paste("Répartition des PME selon", column1, "et", column2),
          xlab = column1, ylab = "Proportion", col = c("blue", "pink"))
  return(cross_tab)
}                                         

bivarie(projet,"sexe","q12")
bivarie(projet,"sexe","q25")
bivarie(projet,"sexe","q81")


                                      #Statistiques descriptives sur les autres variables



#Un peu de cartographie 


library(sf)

# Créer un data.frame factice avec des coordonnées
proj_coords <- data.frame(
  id = 1:5,
  longitude = c(-16.5, -15.5, -14.5, -13.5, -12.5),
  latitude = c(14.5, 15.5, 16.5, 17.5, 18.5)
)

# Convertir en objet géospatial
projet_map <- st_as_sf(proj_coords, coords = c("longitude", "latitude"), crs = 4326)


library(leaflet)

# Créer la carte
senegal_map <- leaflet() %>%
  setView(lng = -14, lat = 15, zoom = 6) %>%
  addTiles()  # Ajouter les tuiles de fond

senegal_map <- senegal_map %>%
  addTiles() %>%
  addTitles("Carte du Sénégal")

# Afficher la carte
senegal_map




